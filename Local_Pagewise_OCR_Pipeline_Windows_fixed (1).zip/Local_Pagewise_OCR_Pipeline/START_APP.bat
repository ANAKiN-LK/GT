@echo off
cd /d "%~dp0"
if not exist .venv\Scripts\python.exe (
  echo Please run INSTALL_WINDOWS_CPU.bat or INSTALL_WINDOWS_GPU_CU126.bat first.
  pause
  exit /b 1
)
.venv\Scripts\python.exe run.py
pause

@echo off
cd /d "%~dp0"
call .venv\Scripts\activate.bat
python -c "import paddle; print('Paddle:',paddle.__version__); print('CUDA:',paddle.is_compiled_with_cuda()); print('Device:',paddle.device.get_device())"
python -c "from paddleocr import PaddleOCR; print('PaddleOCR import OK')"
pause

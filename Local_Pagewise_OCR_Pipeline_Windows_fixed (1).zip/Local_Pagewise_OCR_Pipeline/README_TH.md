# Local Pagewise Document AI Pipeline (Windows / RTX 3050)

## เป้าหมายและข้อจำกัด
ระบบนี้ออกแบบให้รับ PDF หนึ่งไฟล์หรือหลายไฟล์ แล้วเลือก engine แยกตามหน้า **ก่อนทำ OCR** โดยเน้นทางลัดที่เร็วที่สุดก่อน ไม่ได้การันตีว่า PDF ทุกขนาดจะเสร็จใน 30 วินาที เพราะเวลาเพิ่มตามจำนวนหน้า ความละเอียด ตาราง และความซับซ้อนของเอกสาร

## Routing จริงในเวอร์ชันนี้
1. PDF ที่มี embedded/selectable text: ใช้ PyMuPDF ดึงข้อความโดยตรง ไม่เรียก OCR model (เร็วที่สุด)
2. PDF สแกนที่ตรวจพบตารางแบบมีเส้น: ส่ง PaddleOCR-VL 1.6
3. PDF สแกนทั่วไป: ส่ง PP-OCRv5 Thai recognition ซึ่งรองรับ Thai + English
4. โมเดลโหลดแบบ lazy และ reuse: ไม่โหลด VL หากไม่มีหน้าตาราง

หมายเหตุ: การตรวจตารางในเวอร์ชันนี้เป็น heuristic จากเส้นแนวนอน/แนวตั้ง จึงอาจพลาดตารางไร้เส้น (borderless) และอาจส่งหน้าที่มีเส้นอื่นเข้า VL ได้ การตรวจภาษาในหน้า scanned ใช้โมเดล th ซึ่งรองรับไทยและอังกฤษร่วมกัน ไม่ได้สลับเป็นโมเดลอังกฤษแยก

## ติดตั้ง Windows 11
1. ติดตั้ง NVIDIA Driver ล่าสุดที่รองรับ CUDA 12.6 runtime
2. ติดตั้ง Python 3.12 x64
3. แตก ZIP และเข้าโฟลเดอร์โปรเจกต์
4. วาง PDF ใน `input_pdfs`
5. เปิด PowerShell ในโฟลเดอร์โปรเจกต์ แล้วรัน `py -3.12 -m venv .venv` และ ` .\.venv\Scripts\Activate.ps1`
6. ตรวจ `nvidia-smi` ก่อนติดตั้ง GPU build
7. หาก Driver รองรับ CUDA 12.6 ให้รัน `INSTALL_WINDOWS_GPU_CU126.bat`
8. รัน `TEST_ENV.bat`
9. รัน `START_APP.bat`

ถ้า PowerShell บล็อก Activate ให้ใช้ ` .\.venv\Scripts\activate.bat` จาก Command Prompt หรือเปิด CMD แล้วเรียก batch installer แทน อย่าติดตั้ง CPU และ GPU PaddlePaddle ใน environment เดียวกัน

## ความเร็ว / 30 วินาที
- เวลาครั้งแรกมีการดาวน์โหลด model weights จึงไม่นับเป็นเวลาประมวลผลปกติ
- การทดสอบความเร็วควรทำหลัง warm-up 1 ครั้ง และบันทึกจำนวนหน้า, route counts, elapsed_seconds, pages_per_second
- หากต้องการ 30 วินาทีแบบไม่จำกัดจำนวนหน้า เป็น SLA ที่เป็นไปไม่ได้บน RTX 3050 เครื่องเดียว ต้องกำหนดจำนวนหน้า/ขนาดไฟล์/ชนิดเอกสาร หรือเพิ่ม hardware/worker
- ลด DPI เป็น 150 เพื่อความเร็ว; หากตัวอักษรเล็กหรือผลไม่แม่น ให้เพิ่มเป็น 180–200 แล้ว benchmark ใหม่

## Output
- `output/results.jsonl`: หนึ่ง record ต่อหน้า
- `output/summary.csv`: route และเวลาของแต่ละหน้า
- `output/run_summary.json`: เวลารวม, throughput และจำนวนหน้าตาม route
- `output/model_outputs/`: JSON/Markdown ของหน้าที่ส่ง PaddleOCR-VL

## ขอบเขตปัจจุบัน
นี่คือเวอร์ชัน router ที่มีการเลือก engine จริงตามชนิดหน้า แต่ยังเป็น baseline: table detection ยังไม่ครอบคลุม borderless tables, ไม่มี parallel GPU workers, ไม่มี confidence-based fallback และยังไม่ chunk ข้อความ

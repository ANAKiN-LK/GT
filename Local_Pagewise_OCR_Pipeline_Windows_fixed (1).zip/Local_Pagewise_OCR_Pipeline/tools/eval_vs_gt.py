"""Compare a pipeline results.jsonl with a GT jsonl (same page numbering).
usage: python tools/eval_vs_gt.py output/results.jsonl results_gt.jsonl"""
import sys, json, re, unicodedata
try:
    from rapidfuzz.distance import Levenshtein as _L
    def lev(a,b): return _L.distance(a,b)
except Exception:
    def lev(a,b):
        if len(a)<len(b): a,b=b,a
        prev=list(range(len(b)+1))
        for i,ca in enumerate(a,1):
            cur=[i]
            for j,cb in enumerate(b,1):
                cur.append(min(prev[j]+1,cur[j-1]+1,prev[j-1]+(ca!=cb)))
            prev=cur
        return prev[-1]

def norm(s):
    s=unicodedata.normalize("NFC",s)
    s=re.sub(r"^\s*[-–—]\s*","",s)          # bullets are not reliably OCR'd
    return re.sub(r"\s+","",s)

def lines_of(rec):
    if rec.get("elements"): return [e["content"] for e in rec["elements"]]
    ocr=rec.get("ocr") or {}
    if ocr.get("items"): return [x.get("text","") for x in ocr["items"] if x.get("text")]
    return (ocr.get("text") or "").split("\n")

def load(p):
    d={}
    for l in open(p,encoding="utf-8"):
        if l.strip():
            r=json.loads(l); d[r.get("page_number",r.get("page"))]=r
    return d

def main(pred_p,gt_p):
    P,G=load(pred_p),load(gt_p); tot_e=tot_n=0; print(f"{'page':>4} {'status':>8} {'CER':>7} {'GT line recall':>15} {'pred lines':>11} {'GT lines':>9}")
    for pg in sorted(G):
        g=G[pg]; p=P.get(pg)
        gl=[norm(x) for x in lines_of(g) if norm(x)]
        if not p or p.get("status")!="success":
            print(f"{pg:>4} {'ERROR':>8}"); tot_e+=len("".join(gl)); tot_n+=len("".join(gl)); continue
        pl=[norm(x) for x in lines_of(p) if norm(x)]
        gt,pt="".join(gl),"".join(pl); e=lev(pt,gt); tot_e+=e; tot_n+=len(gt)
        # line recall: GT line found (>=90% similar) as a substring-ish match in prediction text
        hit=0
        for line in gl:
            best=min((lev(line,q)/max(len(line),1) for q in pl),default=1)
            if best<=0.10: hit+=1
        print(f"{pg:>4} {'ok':>8} {e/len(gt):7.2%} {hit/len(gl):15.1%} {len(pl):>11} {len(gl):>9}")
    print(f"ALL  CER = {tot_e/max(1,tot_n):.2%}  (edit distance / GT chars; lower is better)")
if __name__=="__main__": main(*sys.argv[1:3])

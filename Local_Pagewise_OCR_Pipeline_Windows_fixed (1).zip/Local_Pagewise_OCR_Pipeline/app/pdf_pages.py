from pathlib import Path
import fitz, cv2, numpy as np

def iter_pdf_page_records(pdf_path: Path, dpi=150):
    """Yield one page at a time. Native PDF text is extracted before rasterization."""
    doc=fitz.open(pdf_path)
    try:
        mat=fitz.Matrix(dpi/72,dpi/72)
        for i,page in enumerate(doc):
            text=page.get_text("text") or ""
            # Only rasterize when the page has no usable embedded text or may contain a table.
            pix=page.get_pixmap(matrix=mat,alpha=False)
            arr=np.frombuffer(pix.samples,dtype=np.uint8).reshape(pix.height,pix.width,pix.n)
            bgr=cv2.cvtColor(arr,cv2.COLOR_RGB2BGR)
            yield i+1, text, bgr
    finally: doc.close()

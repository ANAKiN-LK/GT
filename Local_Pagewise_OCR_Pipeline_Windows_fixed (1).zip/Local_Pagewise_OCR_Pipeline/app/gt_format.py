"""Convert raw engine output into the GT / results.jsonl element schema:
{element_id, type, bbox[x0,y0,x1,y1], content, reading_order, role}
All bboxes are rescaled to `gt_dpi` pixel space (default 180) so they are comparable with the GT file."""
import re, html, hashlib, statistics

THAI = re.compile(r"[\u0E00-\u0E7F]"); LATIN = re.compile(r"[A-Za-z]")
HEAD = re.compile(r"^\s*\d+\.\s+\S")

def document_id(source_file: str) -> str:
    return hashlib.sha1(source_file.encode("utf-8")).hexdigest()[:16]

def _role(text, label=None):
    if label in ("doc_title", "paragraph_title"): return "heading"
    if label == "table": return "table_cell"
    t = text.strip()
    if t.startswith("- "): return "list_item"
    if HEAD.match(t): return "heading"
    return "paragraph"

def _scale(b, s):
    return [round(float(v) * s, 1) for v in b]

def _language(elements):
    txt = "".join(e["content"] for e in elements)
    t, e = len(THAI.findall(txt)), len(LATIN.findall(txt)); n = max(1, t + e)
    if t / n >= .10 and e / n >= .10: return "thai_english_mixed"
    if t / n >= .10: return "thai"
    if e / n >= .10: return "english"
    return "unknown"

def _from_ppocr(items, s, min_conf, drop_small):
    rows = [x for x in items if x.get("text", "").strip() and x.get("bbox")]
    hs = [x["bbox"][3] - x["bbox"][1] for x in rows]
    med = statistics.median(hs) if hs else 0
    out = []
    for x in rows:
        t = x["text"].strip(); b = x["bbox"]; h = b[3] - b[1]; c = x.get("confidence")
        if c is not None and c < min_conf: continue
        if drop_small and len(t) <= 3 and med and h < 0.7 * med: continue   # logo / stamp fragments
        out.append({"type": "text", "bbox": _scale(b, s), "content": t, "role": _role(t), "confidence": None if c is None else round(c, 4)})
    out.sort(key=lambda e: (round(e["bbox"][1] / 12), e["bbox"][0]))   # top-to-bottom, left-to-right
    return out

def _cells(table_html):
    rows = re.findall(r"<tr>(.*?)</tr>", table_html, flags=re.S | re.I)
    return [[html.unescape(re.sub(r"<[^>]+>", "", c)).strip() for c in re.findall(r"<t[dh][^>]*>(.*?)</t[dh]>", r, flags=re.S | re.I)] for r in rows]

def _from_vl(raw_results, s):
    out = []
    for raw in raw_results or []:
        if not isinstance(raw, dict): continue
        res = raw.get("res", raw)
        for blk in res.get("parsing_res_list", []):
            label = blk.get("block_label"); content = (blk.get("block_content") or "").strip(); bb = blk.get("block_bbox")
            if not content or not bb or label in ("header_image", "image", "footer", "footer_image", "seal"): continue
            x0, y0, x1, y1 = bb
            if label == "table":
                grid = _cells(content); nr = max(1, len(grid))
                for ri, row in enumerate(grid):
                    nc = max(1, len(row))
                    for ci, cell in enumerate(row):
                        if not cell: continue
                        cb = [x0 + (x1 - x0) * ci / nc, y0 + (y1 - y0) * ri / nr, x0 + (x1 - x0) * (ci + 1) / nc, y0 + (y1 - y0) * (ri + 1) / nr]
                        out.append({"type": "text", "bbox": _scale(cb, s), "content": cell, "role": "table_cell", "bbox_approx": True})
                continue
            lines = [l.strip() for l in content.split("\n") if l.strip()]
            for i, l in enumerate(lines):          # VL returns block text; split explicit newlines into lines
                lb = [x0, y0 + (y1 - y0) * i / len(lines), x1, y0 + (y1 - y0) * (i + 1) / len(lines)]
                e = {"type": "text", "bbox": _scale(lb, s), "content": l, "role": _role(l, label)}
                if len(lines) == 1 and label not in ("doc_title", "paragraph_title"): e["granularity"] = "block"
                out.append(e)
    return out

def build_gt_fields(result, route, scale, size_px, cfg_out=None):
    cfg_out = cfg_out or {}
    min_conf = float(cfg_out.get("min_confidence", 0.5)); drop_small = bool(cfg_out.get("drop_small_fragments", True))
    if route == "ppocr_th": els = _from_ppocr(result.get("items", []), scale, min_conf, drop_small)
    elif route == "paddleocr_vl": els = _from_vl(result.get("raw_results"), scale)
    else: els = []
    for i, e in enumerate(els, 1): e["element_id"] = i; e["reading_order"] = i
    els = [{k: e[k] for k in ("element_id", "type", "bbox", "content", "reading_order", "role") if k in e} | {k: v for k, v in e.items() if k not in ("element_id", "type", "bbox", "content", "reading_order", "role")} for e in els]
    return {"language": _language(els), "image_size": {"width": round(size_px[0] * scale), "height": round(size_px[1] * scale), "dpi": int(cfg_out.get("gt_dpi", 180))}, "elements": els}

from pathlib import Path
import json, csv, time, traceback, hashlib
import numpy as np
import cv2
from tqdm import tqdm
from .pdf_pages import iter_pdf_page_records
from .classifier import classify_page
from .preprocess import run_preprocess
from .gt_format import build_gt_fields, document_id
from .parser import FastPPRecognizer, PaddleOCRVLParser

def _ascii_stem(name:str)->str:
    """Windows cv2/Paddle workers cannot open non-ASCII (e.g. Thai) paths -> use an ASCII folder name."""
    return "doc_"+hashlib.md5(name.encode("utf-8")).hexdigest()[:8]

def _imwrite(path:Path,img):
    """cv2.imwrite silently fails on non-ASCII Windows paths; imencode+tofile is safe."""
    ok,buf=cv2.imencode(".png",img)
    if not ok: raise RuntimeError("cv2.imencode failed")
    buf.tofile(str(path))
    if not Path(path).exists(): raise RuntimeError(f"Could not write page image: {path}")

def load_cfg(path):
    import yaml
    with open(path,encoding="utf-8") as f: return yaml.safe_load(f)

def run(input_dir:Path, output_dir:Path, cfg_path:Path, progress=None):
    cfg=load_cfg(cfg_path); pdfs=sorted(input_dir.rglob("*.pdf"))
    if not pdfs: raise RuntimeError(f"No PDF files found in {input_dir}")
    output_dir.mkdir(parents=True,exist_ok=True)
    image_root=output_dir/"page_images"; model_root=output_dir/"model_outputs"
    # Lazy loading: only instantiate a model if a page is routed to it.
    ppocr=None; vl=None; summary=[]; total=0; start=time.perf_counter(); model_time=0.0
    jsonl=output_dir/"results.jsonl"
    with open(jsonl,"w",encoding="utf-8") as out:
        for pdf in pdfs:
            for page_no,native_text,bgr in tqdm(iter_pdf_page_records(pdf,int(cfg["pdf"].get("dpi",150))),desc=pdf.name):
                total+=1; t0=time.perf_counter(); rec={"document":pdf.stem,"document_id":document_id(pdf.name),"source_file":pdf.name,"page":page_no,"page_number":page_no}
                try:
                    page_type,route,signals=classify_page(native_text,bgr)
                    if route=="native_text":
                        result={"engine":"PyMuPDF native text extraction","text":native_text,"items":[]}
                    elif route=="ppocr_th":
                        if ppocr is None: ppocr=FastPPRecognizer(cfg)
                        processed,prep=run_preprocess(bgr,cfg.get("preprocess",{}))
                        model_t=time.perf_counter(); result=ppocr.parse(processed); model_time+=time.perf_counter()-model_t
                        result["preprocessing"]=prep
                    elif route=="paddleocr_vl":
                        if vl is None: vl=PaddleOCRVLParser(cfg)
                        processed,prep=run_preprocess(bgr,cfg.get("preprocess",{}))
                        img_dir=image_root/_ascii_stem(pdf.stem); img_dir.mkdir(parents=True,exist_ok=True)
                        img_path=img_dir/f"page_{page_no:04d}.png"
                        _imwrite(img_path,processed)
                        model_t=time.perf_counter(); result=vl.parse(img_path,model_root/_ascii_stem(pdf.stem),cfg); model_time+=time.perf_counter()-model_t
                        result["preprocessing"]=prep
                        if not cfg.get("output",{}).get("keep_vl_page_images",False): img_path.unlink(missing_ok=True)
                    else: raise RuntimeError(f"Unknown route: {route}")
                    rec.update({"status":"success","page_type":page_type,"route":route,"classification":signals,"ocr":result})
                    out_cfg=dict(cfg.get("output",{})); gt_dpi=float(out_cfg.get("gt_dpi",180)); scale=gt_dpi/float(cfg["pdf"].get("dpi",150))
                    rec.update(build_gt_fields(result,route,scale,(bgr.shape[1],bgr.shape[0]),out_cfg))
                    summary.append({"source_file":pdf.name,"page_number":page_no,"page_type":page_type,"route":route,"status":"success","seconds":round(time.perf_counter()-t0,3)})
                except Exception as e:
                    rec.update({"status":"error","error":str(e),"traceback":traceback.format_exc(limit=3)})
                    summary.append({"source_file":pdf.name,"page_number":page_no,"page_type":"error","route":"","status":"error","seconds":round(time.perf_counter()-t0,3)})
                out.write(json.dumps(rec,ensure_ascii=False,default=str)+"\n"); out.flush()
                if progress: progress(total,len(pdfs),pdf.name,page_no)
    with open(output_dir/"summary.csv","w",newline="",encoding="utf-8-sig") as f:
        w=csv.DictWriter(f,fieldnames=["source_file","page_number","page_type","route","status","seconds"]); w.writeheader(); w.writerows(summary)
    elapsed=time.perf_counter()-start
    stats={"pdf_files":len(pdfs),"pages_processed":total,"success_pages":sum(x["status"]=="success" for x in summary),"error_pages":sum(x["status"]=="error" for x in summary),"elapsed_seconds":round(elapsed,2),"pages_per_second":round(total/elapsed,3) if elapsed else None,"model_inference_seconds":round(model_time,2),"route_counts":{}}
    for x in summary: stats["route_counts"][x["route"]]=stats["route_counts"].get(x["route"],0)+1
    (output_dir/"run_summary.json").write_text(json.dumps(stats,ensure_ascii=False,indent=2),encoding="utf-8")
    return stats

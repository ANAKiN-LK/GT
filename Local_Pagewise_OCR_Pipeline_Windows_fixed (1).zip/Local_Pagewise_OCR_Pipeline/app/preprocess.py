import cv2
import numpy as np

def estimate_skew(gray):
    if gray.ndim == 3:
        gray = cv2.cvtColor(gray, cv2.COLOR_BGR2GRAY)
    # Estimate dominant text-line angle with Hough lines after binarization.
    blur = cv2.GaussianBlur(gray, (3, 3), 0)
    edges = cv2.Canny(blur, 50, 150)
    lines = cv2.HoughLinesP(edges, 1, np.pi/180, threshold=100,
                            minLineLength=max(80, gray.shape[1]//8), maxLineGap=15)
    if lines is None:
        return 0.0
    angles = []
    for line in lines[:, 0]:
        x1,y1,x2,y2 = line
        angle = np.degrees(np.arctan2(y2-y1, x2-x1))
        if abs(angle) <= 15:
            angles.append(angle)
    return float(np.median(angles)) if angles else 0.0

def rotate_bound(img, angle):
    h,w = img.shape[:2]
    center = (w/2, h/2)
    m = cv2.getRotationMatrix2D(center, angle, 1.0)
    c,s = abs(m[0,0]), abs(m[0,1])
    nw,nh = int(h*s+w*c), int(h*c+w*s)
    m[0,2] += nw/2-center[0]
    m[1,2] += nh/2-center[1]
    return cv2.warpAffine(img,m,(nw,nh),flags=cv2.INTER_CUBIC,borderMode=cv2.BORDER_REPLICATE)

def run_preprocess(bgr, cfg):
    ops=[]
    angle=estimate_skew(bgr) if cfg.get("deskew",True) else 0.0
    if abs(angle) > 0.25 and abs(angle) <= float(cfg.get("max_skew_degrees",7)):
        bgr=rotate_bound(bgr,-angle)
        ops.append("deskew")
    gray=cv2.cvtColor(bgr,cv2.COLOR_BGR2GRAY)
    if cfg.get("denoise",True):
        gray=cv2.fastNlMeansDenoising(gray,None,7,7,21)
        ops.append("denoise")
    if cfg.get("clahe",True):
        gray=cv2.createCLAHE(clipLimit=1.6,tileGridSize=(8,8)).apply(gray)
        ops.append("clahe")
    # PaddleOCR 3.x expects a 3-channel image (H,W,C). A 2D gray array triggers
    # "not enough values to unpack (expected 3, got 2)", so convert back to BGR.
    out=cv2.cvtColor(gray,cv2.COLOR_GRAY2BGR)
    return out, {"estimated_skew_degrees":round(angle,3),"operations":ops}

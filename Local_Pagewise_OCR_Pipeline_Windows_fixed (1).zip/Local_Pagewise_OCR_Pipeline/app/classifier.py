"""Fast page classifier. Runs BEFORE OCR, using embedded PDF text and image geometry."""
import re
import cv2
import numpy as np

THAI = re.compile(r"[\u0E00-\u0E7F]")
LATIN = re.compile(r"[A-Za-z]")

def language_from_text(text: str):
    t=len(THAI.findall(text or "")); e=len(LATIN.findall(text or "")); total=max(1,t+e)
    tr, er=t/total, e/total
    if tr >= .10 and er >= .10: lang="thai_english_mixed"
    elif tr >= .10: lang="thai"
    elif er >= .10: lang="english"
    else: lang="unknown"
    return lang, {"thai_ratio":round(tr,3),"latin_ratio":round(er,3)}

def detect_table_lines(bgr):
    """Conservative ruled-table detector; catches horizontal/vertical line grids."""
    gray=cv2.cvtColor(bgr,cv2.COLOR_BGR2GRAY) if bgr.ndim==3 else bgr
    h,w=gray.shape[:2]
    bw=cv2.adaptiveThreshold(gray,255,cv2.ADAPTIVE_THRESH_MEAN_C,cv2.THRESH_BINARY_INV,31,15)
    hk=cv2.getStructuringElement(cv2.MORPH_RECT,(max(20,w//24),1))
    vk=cv2.getStructuringElement(cv2.MORPH_RECT,(1,max(20,h//24)))
    horizontal=cv2.morphologyEx(bw,cv2.MORPH_OPEN,hk)
    vertical=cv2.morphologyEx(bw,cv2.MORPH_OPEN,vk)
    hn=cv2.countNonZero(horizontal); vn=cv2.countNonZero(vertical)
    density=(hn+vn)/float(h*w)
    hlines=cv2.HoughLinesP(horizontal,1,np.pi/180,threshold=max(20,w//20),minLineLength=w//5,maxLineGap=12)
    vlines=cv2.HoughLinesP(vertical,1,np.pi/180,threshold=max(20,h//20),minLineLength=h//5,maxLineGap=12)
    hc=0 if hlines is None else len(hlines); vc=0 if vlines is None else len(vlines)
    # Need multiple rows/columns to avoid classifying a single underline as a table.
    is_table=hc>=2 and vc>=2 and density>=0.002
    return is_table,{"horizontal_lines":hc,"vertical_lines":vc,"line_density":round(density,5)}

def classify_page(native_text: str, image=None):
    """Routes native-text pages to extraction; image tables to VL; other scans to PP-OCR."""
    lang, lang_signals=language_from_text(native_text)
    if (native_text or '').strip() and len((native_text or '').strip()) >= 30:
        table, table_signals=detect_table_lines(image) if image is not None else (False,{})
        if table:
            return "native_text_table", "native_text", {**lang_signals,**table_signals}
        return f"native_text_{lang}", "native_text", lang_signals
    if image is not None:
        table, table_signals=detect_table_lines(image)
        if table:
            return "scanned_table", "paddleocr_vl", {**lang_signals,**table_signals}
    return "scanned_text_th_en", "ppocr_th", lang_signals

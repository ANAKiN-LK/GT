from pathlib import Path
import tkinter as tk
from tkinter import filedialog, messagebox, ttk
import threading
from .pipeline import run

ROOT=Path(__file__).resolve().parents[1]
class App:
    def __init__(self,root):
        self.root=root; root.title("Modular Document AI Pipeline"); root.geometry("760x500")
        self.input_var=tk.StringVar(value=str(ROOT/"input_pdfs"))
        self.output_var=tk.StringVar(value=str(ROOT/"output"))
        ttk.Label(root,text="MODULAR DOCUMENT AI PIPELINE",font=("Segoe UI",17,"bold")).pack(pady=18)
        frame=ttk.Frame(root,padding=14); frame.pack(fill="x")
        ttk.Label(frame,text="PDF input folder").grid(row=0,column=0,sticky="w")
        ttk.Entry(frame,textvariable=self.input_var,width=70).grid(row=1,column=0,padx=(0,8),pady=6)
        ttk.Button(frame,text="Browse",command=self.browse_input).grid(row=1,column=1)
        ttk.Label(frame,text="Output folder").grid(row=2,column=0,sticky="w")
        ttk.Entry(frame,textvariable=self.output_var,width=70).grid(row=3,column=0,padx=(0,8),pady=6)
        ttk.Button(frame,text="Browse",command=self.browse_output).grid(row=3,column=1)
        self.status=ttk.Label(root,text="Put all PDF files in input_pdfs, then click Start.")
        self.status.pack(pady=8)
        self.bar=ttk.Progressbar(root,mode="indeterminate",length=650); self.bar.pack(pady=8)
        ttk.Button(root,text="START PROCESSING",command=self.start).pack(pady=15,ipadx=24,ipady=10)
        ttk.Label(root,text="Page-wise routing • Native text / PP-OCR Thai+English / VL tables • Local processing",foreground="gray").pack(pady=10)
    def browse_input(self):
        p=filedialog.askdirectory()
        if p:self.input_var.set(p)
    def browse_output(self):
        p=filedialog.askdirectory()
        if p:self.output_var.set(p)
    def start(self):
        if not Path(self.input_var.get()).exists():
            messagebox.showerror("Input not found","Please select a valid PDF folder."); return
        self.bar.start(12); self.status.config(text="Starting models and processing PDFs...")
        threading.Thread(target=self.worker,daemon=True).start()
    def worker(self):
        try:
            stats=run(Path(self.input_var.get()),Path(self.output_var.get()),ROOT/"config"/"settings.yaml")
            self.root.after(0,lambda:self.done(stats))
        except Exception as e:
            self.root.after(0,lambda:messagebox.showerror("Pipeline error",str(e)))
            self.root.after(0,lambda:self.bar.stop())
    def done(self,stats):
        self.bar.stop()
        self.status.config(text=f"Finished: {stats['pdf_files']} PDFs | {stats['pages_processed']} pages | {stats['error_pages']} errors")
        messagebox.showinfo("Completed",f"Processed {stats['pages_processed']} pages.\\nResults: {self.output_var.get()}")
def main():
    root=tk.Tk(); App(root); root.mainloop()
if __name__=="__main__":main()

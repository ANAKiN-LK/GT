"""Lazy model adapters. Each model is initialized once and reused for all routed pages."""
from pathlib import Path

def _boxes(payload,n):
    """Return [x0,y0,x1,y1] per recognized line (rec_boxes, else bounding box of rec_polys/dt_polys)."""
    rb=payload.get("rec_boxes") if isinstance(payload,dict) else None
    if rb is not None and len(rb)==n: return [[float(v) for v in b] for b in rb]
    for key in ("rec_polys","dt_polys"):
        polys=payload.get(key) if isinstance(payload,dict) else None
        if polys is not None and len(polys)==n:
            out=[]
            for poly in polys:
                xs=[float(pt[0]) for pt in poly]; ys=[float(pt[1]) for pt in poly]
                out.append([min(xs),min(ys),max(xs),max(ys)])
            return out
    return [None]*n

class FastPPRecognizer:
    def __init__(self, cfg):
        from paddleocr import PaddleOCR
        p=cfg.get("ppocr",{})
        self.ocr=PaddleOCR(
            lang=p.get("lang","th"),
            ocr_version=p.get("ocr_version","PP-OCRv5"),
            device=p.get("device","gpu:0"),
            use_doc_orientation_classify=False,
            use_doc_unwarping=False,
            use_textline_orientation=False,
        )
    def parse(self, image):
        results=self.ocr.predict(image)
        rows=[]
        for res in results or []:
            data=getattr(res,"json",None)
            if callable(data): data=data()
            if isinstance(data,dict):
                payload=data.get("res",data)
                texts=payload.get("rec_texts",[]) if isinstance(payload,dict) else []
                scores=payload.get("rec_scores",[]) if isinstance(payload,dict) else []
                boxes=_boxes(payload,len(texts))
                rows.extend({"text":str(t),"confidence":float(scores[i]) if i<len(scores) else None,"bbox":boxes[i]} for i,t in enumerate(texts))
            else:
                rows.append({"raw":str(res)})
        return {"engine":"PP-OCRv5-th (Thai+English)","items":rows,"text":"\n".join(x.get("text","") for x in rows)}

class PaddleOCRVLParser:
    def __init__(self, cfg):
        from paddleocr import PaddleOCRVL
        p=cfg.get("paddleocr_vl",{})
        self.pipeline=PaddleOCRVL(pipeline_version=p.get("pipeline_version","v1.6"))
    def parse(self, image_path: Path, save_dir: Path, cfg):
        save_dir.mkdir(parents=True,exist_ok=True)
        results=self.pipeline.predict(str(image_path))
        outputs=[]; texts=[]
        for res in results or []:
            if cfg.get("output",{}).get("save_model_json",True): res.save_to_json(save_path=save_dir)
            if cfg.get("output",{}).get("save_model_markdown",True): res.save_to_markdown(save_path=save_dir)
            raw=getattr(res,"json",None)
            if callable(raw): raw=raw()
            if isinstance(raw,str):
                import json
                try: raw=json.loads(raw)
                except Exception: pass
            outputs.append(raw if raw is not None else str(res))
            texts.append(str(raw if raw is not None else res))
        return {"engine":"PaddleOCR-VL-1.6","raw_results":outputs,"text":"\n".join(texts)}
